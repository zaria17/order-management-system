package com.example.demo.service.impl;

import com.example.demo.entity.每家供应商供应产品的单价总金额;
import com.example.demo.mapper.每家供应商供应产品的单价总金额Mapper;
import com.example.demo.service.每家供应商供应产品的单价总金额Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
@Service
public class 每家供应商供应产品的单价总金额ServiceImpl extends ServiceImpl<每家供应商供应产品的单价总金额Mapper, 每家供应商供应产品的单价总金额> implements 每家供应商供应产品的单价总金额Service {

}
