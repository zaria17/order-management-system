package com.example.demo.service;

import com.example.demo.entity.折扣表;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-13
 */
public interface 折扣表Service extends IService<折扣表> {

}
