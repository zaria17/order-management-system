package com.example.demo.service;

import com.example.demo.entity.订购库存;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-14
 */
public interface 订购库存Service extends IService<订购库存> {

}
