package com.example.demo.service;

import com.example.demo.entity.每家供应商供应产品的单价总金额;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
public interface 每家供应商供应产品的单价总金额Service extends IService<每家供应商供应产品的单价总金额> {

}
