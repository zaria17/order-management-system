package com.example.demo.service;

import com.example.demo.entity.产品库存量;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-14
 */
public interface 产品库存量Service extends IService<产品库存量> {

}
