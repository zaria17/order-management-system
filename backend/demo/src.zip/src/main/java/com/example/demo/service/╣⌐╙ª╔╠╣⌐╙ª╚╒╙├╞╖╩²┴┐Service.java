package com.example.demo.service;

import com.example.demo.entity.供应商供应日用品数量;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
public interface 供应商供应日用品数量Service extends IService<供应商供应日用品数量> {

}
