package com.example.demo.mapper;

import com.example.demo.entity.每家供应商供应产品的单价总金额;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
@Mapper
public interface 每家供应商供应产品的单价总金额Mapper extends BaseMapper<每家供应商供应产品的单价总金额> {

}
