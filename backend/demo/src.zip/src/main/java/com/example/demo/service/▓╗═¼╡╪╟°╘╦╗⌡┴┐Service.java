package com.example.demo.service;

import com.example.demo.entity.不同地区运货量;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
public interface 不同地区运货量Service extends IService<不同地区运货量> {

}
