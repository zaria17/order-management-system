package com.example.demo.mapper;

import com.example.demo.entity.雇员承接订单数;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
@Mapper
public interface 雇员承接订单数Mapper extends BaseMapper<雇员承接订单数> {

}
