package com.example.demo.service;

import com.example.demo.entity.客户操作记录;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-13
 */
public interface 客户操作记录Service extends IService<客户操作记录> {

}
