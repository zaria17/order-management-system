package com.example.demo.service;

import com.example.demo.entity.订单操作记录;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-13
 */
public interface 订单操作记录Service extends IService<订单操作记录> {

}
