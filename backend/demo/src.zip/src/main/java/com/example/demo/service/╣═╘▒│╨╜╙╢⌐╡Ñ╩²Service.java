package com.example.demo.service;

import com.example.demo.entity.雇员承接订单数;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
public interface 雇员承接订单数Service extends IService<雇员承接订单数> {

}
