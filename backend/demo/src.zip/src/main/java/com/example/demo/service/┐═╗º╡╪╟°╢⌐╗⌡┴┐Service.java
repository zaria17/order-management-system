package com.example.demo.service;

import com.example.demo.entity.客户地区订货量;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author watchdoges
 * @since 2024-04-19
 */
public interface 客户地区订货量Service extends IService<客户地区订货量> {

}
